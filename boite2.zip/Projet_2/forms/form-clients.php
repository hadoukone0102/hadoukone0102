<?php require_once('../forms-config/config-forms-clients.php'); ?>
<?php require('../functions/auth.php'); ?>
<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Clients</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" 
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../CSS/style-forms-clients.css">
</head>
<body>
    <div class="container">

        <div class="content">
            <h1> <i class="fas fa-user-circle"></i> form Clients </h1>
            <form action="#" class="form-box" method="post">
                <div class="name">

                    <h3>info personnel</h3>
                    <div class="input-block">
                        <label for="Name">name <span>*</span></label>
                        <input type="text" placeholder="your Name..." name="nom-clients" autocomplete="off" required>
                    </div>

                    <div class="input-block">
                        <label for="Name">last-Name <span>*</span></label>
                        <input type="text" placeholder="your last-Name..." name="prenom-clients" autocomplete="off" required>
                    </div>
                    
                    <div class="input-block">
                        <label for="Name">Addresse <span>*</span></label>
                        <input type="text" placeholder="your addresse..." name="adresse-clients" autocomplete="off">
                    </div>
                    
                </div>
                <div class="name">
                    <h3>Name 2</h3>
                    <div class="input-block">
                        <label for="statut">Statut <span>*</span></label>
                        <select name="statut" id="statut">
                            <option value="select please"></option>
                            <option value="enfant">Enfant</option>
                            <option value="jeune">Jeune</option>
                            <option value="adult">Adult</option>
                        </select>    
                    </div>
                    
                    <div class="input-block">
                        <label for="size">Tailles <span>*</span></label>
                        <select name="taille" id="statut">
                            <option value="select please"></option>
                            <option value="X">X</option>
                            <option value="XL">XL</option>
                            <option value="L">L</option>
                            <option value="XM">XM</option>
                            <option value="M">M</option>
                        </select>
                    </div>
                    
                    <div class="input-block">
                        <label for="Mesures">Mesures <span>*</span></label>
                        <select name="mesures" id="statut">
                            <option value="select please"></option>
                            <option value="personnel">personnel</option>
                            <option value="aucun">aucun</option>
                        </select>
                    </div>
                    
                </div>
                <div class="name">
                    <h3>Name 3</h3>
                    <div class="input-block">
                        <label for="city">villes <span>*</span></label>
                        <select name="villes" id="statut">
                            <option value="select please"></option>
                            <option value="Abidjan">Abidjan</option>
                            <option value="cocody">cocody</option>
                            <option value="angré">angré</option>
                        </select>
                    </div>
                   
                    <div class="input-block">
                        <label for="quartier">quartier <span>*</span></label>
                        <select name="quartier" id="statut">
                            <option value=""></option>
                            <option value="Masculin"></option>
                            <option value="aux allé">aux allé</option>
                        </select>
                    </div>
                    
                    <div class="input-block">
                        <label for="number">Number <span>*</span></label>
                        <input type="text" placeholder="your Name..." name="number">
                    </div>
                    
                </div>
                <div class="name">
                   
                <div class="input-block">
                        <label for="number">sexe <span>*</span></label>
                        <select name="sexe" id="statut">
                            <option value="select please"></option>
                            <option value="Masculin">Masculin</option>
                            <option value="Feminin">Feminin</option>
                        </select>
                    </div>
                   
                    <div class="input-block">
                        <label for=""></label>
                        <input type="submit" class="btn" value="continuer" name="send">
                    </div>
                    <div class="input-block">
                        <p style="color:red;"><?php  if(isset($error)){echo"$error";} ?> </p>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>