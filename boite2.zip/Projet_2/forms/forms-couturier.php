<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Couturiers</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" 
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../CSS/style-forms-couturiers.css">
</head>
<body>
    
    <div class="container">

        <form action="#">
            <h3 class="header">form Couturiers</h3>
            <div class="form-first">

                <div class="name">
                    <h3>personnel details</h3>
                    <div class="input-fils">
                        <label for="Name">name <span>*</span></label>
                        <input type="text" placeholder="your Name..." autocomplete="off" name="nomCouture" require>
                    </div>
                    <div class="input-fils">
                        <label for="Name">last-Name <span>*</span></label>
                        <input type="text" placeholder="your last-Name..." autocomplete="off" name="prenomCouture" require>
                    </div>
                    <div class="input-fils">
                        <label for="Name">Phone Number <span>*</span></label>
                        <input type="number" placeholder="your number..." autocomplete="off" name="phoneCouture" require>
                    </div>
                </div>


                <div class="name">
                    <h3>identify details</h3>
                    <div class="input-fils">
                        <label for="Name">Sexe <span>*</span></label>
                        <select name="sexe" id="statut" require>
                            <option value="selectioner..."></option>
                            <option value="Masculin">Masculin</option>
                            <option value="Femenin">Femenin</option>
                        </select>
                       
                    </div>
                  
                    <div class="input-fils">
                        <label for="Ville">Ville <span>*</span></label>
                        <select name="villes" id="statut" require>
                            <option value="selectioner..."></option>
                            <option value="Abidjan">Abidjan</option>
                            <option value="Bouake">Bouake</option>
                            <option value="Daloa">Daloa</option>
                        </select>
                       
                    </div>
                    <div class="input-fils">
                        <label for="Name">quartier <span>*</span></label>
                        <select name="quartier" id="statut" require>
                            <option value="selectioner..."></option>
                            <option value="Angré">Angré</option>
                            <option value="Koumassi">Koumassi</option>
                            <option value="Abobo">Abobo</option>
                        </select>
                       
                    </div>
                </div>

                <div class="name">
                    <h3>identify details</h3>

                    <div class="input-fils">
                   
                        <label for="Name">specialites <span>*</span></label> 
                          <select name="specialites" id="statut" require>
                            <option value="selectioner..."></option>
                            <option value="Enfants">Enfants</option>
                            <option value="Adolescants">Adolescants</option>
                            <option value="Jeune Filles">Jeunes Filles</option>
                            <option value="Jeune Filles">Jeunes Filles et hommes</option>
                            <option value="Jeunes hommes">Jeunes hommes</option>
                            <option value="Homme">Hommes et Femmes</option>
                            <option value="Homme">Hommes</option>
                            <option value="Femmes">Femmes</option>
                            <option value="Tous...">Tous...</option>

                        </select>
                    </div>
                    <div class="input-fils">
                        <label for="Name">adresse <span>*</span></label>
                        <input type="text" placeholder="your adresse..." autocomplete="off" name="adresse" require>
                    </div>
                    <div class="input-fils">
                        <label for="Name">experiences <span>*</span></label>
                        <select name="experiences" id="statut" require>
                            <option value="selectioner..."></option>
                            <option value="1 (un) an d'experience">1(un) an d'experience</option>
                            <option value="moins de 5ans d'experiences">moins de 5ans d'experiences</option>
                            <option value="moins de 10ans d'experiences">moins de 10ans d'experiences</option>
                            <option value="Plus de 5ans d'experinces">Plus de 5ans d'experinces</option>
                            <option value="Plus de 10ans d'experinces">Plus de 10ans d'experinces</option>
                            <option value="Plus de 20ans d'experinces">Plus de 20ans d'experinces</option>
                            <option value="moins de 20ans d'experinces">moins de 20ans d'experinces</option>
                        </select>
                    </div>
                   
                </div>

                <div class="name">

                <div class="input-fils">
                        <label for="Name">photo <span>*</span></label>
                        <input type="file" name="photo" require id="files">
                    </div>
                    <div class="input-fils">
                        <label for="Name">CNI <span>*</span></label>
                        <input type="file" name="cni" require id="files">
                    </div>
                    
                    <div class="input-fils">
                        <label for="submit"></label>
                       <input type="submit" value="continuer" name="continuer" class="btn buttons" id="btn">
                    </div>
                </div>

            </div>
        </form>
    </div>

<script src="../JS/js-forms.js"></script>
</body>
</html>