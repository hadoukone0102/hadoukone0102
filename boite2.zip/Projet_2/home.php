<?php
require_once('forms-config/config-forms-clients.php');
require('functions/auth.php');
require_once ('db.class.php');

 session_start();
 //var_dump($_SESSION['connecter']);
 if($_SESSION['connecter']){

 }else{
    header('location:forms/form-clients.php');
    exit();
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>fashion house</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" 
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<?php ?>
    <header class="precis">
        <div class="header-1">
            <a href="#" class="logo"><i class=""></i>Fashion House</a>
            <div class="image">
                <img src="" alt="">
            </div>
            <form action="#" class="header-box-container">
                <input type="search" class="inputSearch" id="inputSearch" placeholder="Search..." autocomplete="off">
                <label for="input-search" class="fas fa-search"></label>
            </form>
            
        </div>
        <div class="header-2">
            <div id="menuBar" class="fas fa-bars"></div>
            <nav class="nabar">
                <a href="#" id="home">Home</a>
                <a href="#" id="liste">Liste</a>
                <a href="#" id="product">Products</a>
                <a href="#" id="about">About</a>
                <a href="#" id="contact">Contact</a>
            </nav>
            <div class="icons">
                <a href="#" class="fas fa-heart" id="coeur"></a>
                <a href="#" class="fas fa-shopping-cart"></a>
                <a href="/forms/choix.php" target="_blank" class="fas fa-user-circle"></a>
                <a href="#" id="troispoints" class="fa-solid fa-ellipsis"></a>
                <li><pre><?= $_SESSION['connecter'][0]; ?></pre></li>
            </div>
            <div class="dots">
                <ul>
                    <li><a href="#">kone <i class="fas fa-arrow-top"></i></a></li>
                    <li><a href="#">kone</a></li>
                    <li><a href="#">kone</a></li>
                    <li><a href="#">kone</a></li>
                </ul>
            </div>
        </div>
    </header>
<!---->
<!-- section principale-->
    <section class="container">
        <!--la partie juste à coté-->
        <div class="first">

            <section class="links" id="links">
                <div class="nav-links">
                  <div class="boiteDuMenu">
                    
                    <nav class="nav-link-menu">
                        <a href="#" class="">Propositions</a>
                        <a href="#">Les Modeles</a>
                        <a href="#">Commandes</a>
                        <a href="#">Publier</a>
                    </nav>

                  </div>
                  
                  <div class="boiteDuMenu">
                    
                    <nav class="nav-link-menu">
                        <a href="#" class="">Propositions</a>
                        <a href="#">Les Modeles</a>
                        <a href="#">Commandes</a>
                        <a href="#">Publier</a>
                    </nav>

                  </div>
                    <div class="nav-p-links">
                            <h3>Autre</h3>
                    </div>
                </div>
            </section>
        </div>
        <!-- end-->

        <!-- la boite principale-->
        <div class="main-content">
            <section class="deroulant" id="deroulant">
                <!-- la partie transparente du forms-->
                <div class="transparnt"></div>

                <div class="form-part-1">

                    <div class="login">
                        <h1>login</h1>
                        <form action="#">
                            <div class="lg">
                                <input type="text" placeholder="Name">
                                <input type="text" placeholder="Name">
                           </div>
                        </form>
                    </div>

                    <div class="signup">
                        <h1>signup</h1>
                        <form action="#">
                           <div class="snp">
                                <input type="text" placeholder="Name">
                                <input type="text" placeholder="Name">
                           </div>
                        </form>
                    </div>

                </div>

                <!-- Avec le formulaire-->

                <p>merci papa maman</p>
                
            </section>
           
            <!---->
        </div>
        <!--end-->
    
    </section>
 <!--#############################################################################################################-->
    <!-- start section pour width= 768px -->
    <section class="second-boite">
        <section  class="second-content">
        
                <div class="head-image">
                    <div class="resources">
                        <span>Bienvenue sur fashion house</span>
                        <a href="#" class="btn">Commencer</a>
                    </div>
                </div>
        </section> 

        <section class="presentation">
            <h3 class="separateur">Les Meilleurs du <span>fashion house</span></h3>

            <div class="present-function">

                <div class="box-present">
                    <img src="img/cake1.png" alt="">
                    <div class="details-present">
                        <span>15 ans esperience</span>
                        <h3>mes specialités:
                            <ul>
                                <li>Enfants</li>
                                <li>Jeunes Filles</li>
                                <li>Femmes</li>
                            </ul>
                        </h3>
                        
                    </div>
                    <a href="#" class="btn">Me contacter</a>
                </div>

                <div class="box-present">
                    <img src="img/cake1.png" alt="">
                    <div class="details-present">
                        <span>20 ans d'esperience</span>
                        <h3>mes specialités:
                            <ul>
                                <li>Enfants</li>
                                <li>Hommes</li>
                            </ul>
                        </h3>
                      
                    </div>
                    <a href="#" class="btn">Me contacter</a>
                </div>
            </div>
        </section>

        <section>
            <h3 class="separateur">Le plaisir du <span>fashion house</span></h3>
        </section>
    </section>
    <!--end-->
    <!---->

    <script src="JS/script.js"></script>
</body>
</html>