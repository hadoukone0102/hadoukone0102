<?php

if(isset($_POST['send'])){
    if(
        !empty($_POST['nom-clients']) && 
        !empty($_POST['prenom-clients']) &&  
        !empty($_POST['adresse-clients']) && 
        !empty($_POST['statut']) && 
        !empty($_POST['taille']) && 
        !empty($_POST['mesures']) && 
        !empty($_POST['villes']) && 
        !empty($_POST['quartier']) && 
        !empty($_POST['number']) &&
        !empty($_POST['sexe'])
        )
        {

            $NomClients = $_POST['nom-clients'];
            $PrenomClient = $_POST['prenom-clients'];
            $addressClients = $_POST['adresse-clients'];
            $statutsClients = $_POST['statut'];
            $tailleClients = $_POST['taille'];
            $mesuresClients =$_POST['mesures'];
            $villeClients =$_POST['villes'];
            $quartierClients =$_POST['quartier'];
            $phoneClients =$_POST['number'];
            $sexeClients = $_POST['sexe'];

            $info_clients =array($NomClients ,$PrenomClient);
            //require('../functions/auth.php');
            session_start();
            $_SESSION['connecter'] = $info_clients ;
            if(!empty($_SESSION['connecter'])){
                header('location:../home.php');
            }else{
                header('location:../index.html');
            }
           // header('location:../home.php');
           
         

    }
    else{
            $error ="impossible d'acceder à la page";
    }
}



/* =>  */





?>