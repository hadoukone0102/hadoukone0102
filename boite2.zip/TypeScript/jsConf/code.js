"use strict";
const compteur = document.getElementById('select');
let i = 0;
const enMarche = (e) => {
    e.preventDefault();
    i++;
    const span = compteur === null || compteur === void 0 ? void 0 : compteur.querySelector('span');
    if (span) {
        span.innerText = i.toString();
    }
};
compteur === null || compteur === void 0 ? void 0 : compteur.addEventListener('click', enMarche);
// creation d'une function le narowing( le typage de typeScript)
function PrintId(id) {
    if (typeof id == 'number') {
        console.log((id * 3).toString());
    }
    else {
        console.log('id est de type string');
    }
}
PrintId("bonjour");
