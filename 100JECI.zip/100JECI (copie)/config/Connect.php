<?php  
require_once('database.php');
session_start();

/* pour le formulaire de connexion et inscription */

if(isset($_POST['inscription'])){
    if(!empty($_POST['nom_clients']) and !empty($_POST['prenom_clients']) and !empty($_POST['pseudo_clients']) and !empty($_POST['mdp_clients'])){
        
        // declaration des variables .
        $nom_client = $_POST['nom_clients'];
        $prenom_clients = $_POST['prenom_clients'];
        $pseudo_client = $_POST['pseudo_clients'];
        $mdp_client = $_POST['mdp_clients'];
        $email_clients = $_POST['email_clients'];

        // insertion dans la bas e de donnée en PDO
        $requete ="INSERT INTO clients (nom, prenom, email, pseudo, mdp) VALUES (:nom, :prenom, :email, :pseudo, :mdp)";
        $preparation = $conn->prepare($requete);

        // Liaison des valeurs aux marqueurs de paramètres de la requête
        $preparation ->bindParam(':nom', $nom_client);
        $preparation ->bindParam(':prenom', $prenom_clients);
        $preparation ->bindParam(':email', $email_clients);
        $preparation ->bindParam(':pseudo', $pseudo_client);
        $preparation ->bindParam(':mdp',  $mdp_client);
        // execution du code
        $resultat = $preparation->execute();

        if($resultat){
            //session_start();
            $info_client = array($pseudo_client);
            $_SESSION['nom']= $info_client[0] ;
        }
        // stockage dans un tableau
        $resultat = $preparation->fetchAll();     
        
    }
    else{
        
    }
}

if(isset($_POST['connection'])){
    if(!empty($_POST['pseudo_connect']) and !empty($_POST['mdp_connect'])){

        $pseudo_connect = $_POST['pseudo_connect'];
        $mdp_connect =$_POST['mdp_connect'];

        $requete_selection ="SELECT id_clients,pseudo,mdp FROM `clients` WHERE pseudo= :pseudo";
        $prepare_selection = $conn->prepare($requete_selection);
        $prepare_selection->bindParam(':pseudo', $pseudo_connect);
        $resultat_selection = $prepare_selection->execute();

        $stock_result=$prepare_selection->fetch();
        if($stock_result && password_verify($mdp_connect, $stock_result['mdp'])){
            
            $_SESSION['id_clients']= $stock_result['id_clients'];
            header('location:../index.php');
        }
    }
}

/*
// Préparation de la requête d'insertion
$stmt = $conn->prepare("INSERT INTO ma_table (colonne1, colonne2, colonne3) VALUES (:colonne1, :colonne2, :colonne3)");

// Liaison des valeurs aux marqueurs de paramètres de la requête
$stmt->bindParam(':colonne1', $valeur1);
$stmt->bindParam(':colonne2', $valeur2);
$stmt->bindParam(':colonne3', $valeur3);

// Définition des valeurs à insérer
$valeur1 = "valeur1";
$valeur2 = "valeur2";
$valeur3 = "valeur3";

// Exécution de la requête d'insertion
$stmt->execute();

echo "Données insérées avec succès.";

*/

?>
