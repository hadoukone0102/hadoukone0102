<?php  
require_once("config/Connect.php");
session_start();
if(isset($_SESSION['nom'])){
    $bienvenu = "Bienvenue" .$_SESSION['nom']; 
}
 //var_dump($stock_result);
 //if(isset($bienvenu){echo $bienvenu})
?>

<?php  ?>
<?php  ?>
<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>100JECI</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/style-forms.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" 
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    
    <header>
        <div class="first-part">
            <a href="#" class="logo">100JECI-SARL</a>
            <form action="#" class="form-first">
            <div class="bocks">
                <input type="search" placeholder="search..." class="input-search">
            </div>
                <label for="forSearch" class="fas fa-search"></label>
           
            </form>
        </div>
        <div class="second-part">
            <div id="menuBar" class="fas fa-bars"></div>
            <nav class="nav-bar">
                <a href="#" id="presentation">Accueil</a>
                <a href="#" id="archivre">Actualités</a>
                <a href="#">A propos de nous</a>
            </nav>
            <nav class="nav-bar-2">
                <a href="#" class="" id="Ouvre">Se connecté</a>
                <a href="#" class="" id="utilisateur">S'inscrire</a>
                <a href="#"><?php //echo"$bienvenu " ?></a>
            </nav>
        </div>
    </header>

        <section class="froms">
            <div class="popup">
                <form action="#" class="container-popup" method="POST">
                <div id="first-part">
                    <span class="close" id="close">&times;</span>
                    <div class="form-boite">
                        <label for="utilisateur">Peseudo <span class="red">*</span></label>
                        <input type="text" autocomplete="off" name="pseudo_connect" require >
                    </div>
                    <div class="form-boite">
                        <label for="utilisateur">Mot de passe <span class="red">*</span></label>
                        <input type="password" autocomplete="off" name="mdp_connect" require >
                    </div>
                    <div class="En-flex">
                            <div class="lien-mdp">
                                <button class="btn" name="connection">connection</button>
                            </div>
                            <div class="lien-mdp">
                                <a href="#" class="" id="changement-2">S'inscrire</a>
                            </div>
                    </div>
                   
                    <style>
                        .En-flex{
                                
                                display: flex;
                                padding: .5rem;
                            }
                        .En-flex .lien-mdp{
                            display:block;
                        }
                        .En-flex .lien-mdp a{
                            display:block;
                            line-height:7;
                        }

                    </style>
                </div>
                </form>
            </div>

            <div class="popup-2">
                <form action="#" class="container-popup" method="POST">
                <div id="first-part">
                    <span class="close" id="close2">&times;</span>
                    <div class="form-boite">
                        <div class="perso">
                            <label for="Name">Nom <span class="red">*</span></label>
                            <input type="text" class="perso-name" autocomplete="off" require name="nom_clients">
                        </div>
                        <div class="perso">
                            <label for="Name">Prenom <span class="red">*</span></label>
                            <input type="text" class="perso-name" autocomplete="off" require name="prenom_clients">
                        </div>
                    </div>
                    <div class="form-boite">
                        
                        <div class="perso">
                            <label for="Name">E-mail <span class="red">*</span></label>
                            <input type="email" class="perso-name" autocomplete="off" require name="email_clients">
                        </div>
                    </div>
                    <div class="form-boite">
                        <label for="utilisateur">Peseudo <span class="red">*</span></label>
                        <input type="text" autocomplete="off" require name="pseudo_clients">
                    </div>
                    <div class="form-boite">
                        <label for="utilisateur">Mot de passe <span class="red">*</span></label>
                        <input type="password" autocomplete="off" require name="mdp_clients">
                    </div>
                    <div class="En-flex">
                            <div class="lien-mdp">
                                <button class="btn" name="inscription">connection</button>
                            </div>
                            <div class="lien-mdp">
                                <a href="#" class="" id="changement-1">Se Connecter</a>
                                <?php if(isset($erreur)){var_dump($erreur);}  ?>
                            </div>
                    </div>
                </div>
                </form>
            </div>


            <div class="popup-adherent">
                <div class="popup-content">
                    <span class="close-adherent" id="close3">&times;</span>


                    <div class="cmnt-mbrs">
                        <h3> comment etre Membre de 100JECI</h3>
                        <div class="mbrs-listes">
                            <p class="elements">
                                    L'adhésion à 100JECI-SARL s’élève à 15.000 FCFA non remboursable.
                                    Être une personne de bonne moralité.
                                    Être âgé de 21 ans révolus.
                                    Pour les personnes âgées de moins de 21 ans, avoir une autorisation parentale visée en bonne et due forme.
                                    Avoir rempli correctement la fiche d'adhésion et la signer.
                                    Remplir une fiche d’inscription et s’acquitter de son droit d’inscription. 
                            </p>
                            <h3 id="titre">QUELS SONT LES STATUS ET LEUR AVANTAGES?</h3>
                            <div class="je-cites">
                                <p><i class="fa-solid fa-check" id="meme"></i><span id="meme">Adhérent:</span>
                                    Il peut profiter des offres d'emploi rémunérées 
                                    et/ou des appels d'offre pour l'exécution d'un projet.
                                </p>
                                    <p><i class="fa-solid fa-check" id="meme"></i><span id="meme">Partenaire:</span>
                                        Il profite d'un retour sur investissement (RSI) sur une période définie en fonction du Projet.
                                    </p>
                                    <p><i class="fa-solid fa-check" id="meme"></i><span id="meme">Actionnaire:</span>
                                        Il est copropriétaire sur un projet défini et ceux tant que le projet existe.
                                         Il reçoit également un RSI en fonction du projet.
                                    </p>
                            </div>
                        </div>
                    </div>


                    <form action="#" class="etre-membre">
                        <h3>Adherer un nouveau Projet</h3>
                    <div class="menbre-boite">
                        <div class="membre-bts">
                            <div class="bts-input">
                                <label for="Name">Nom <span class="red">*</span></label>
                                <input type="text" autocomplete="off" placeholder="Votre Nom..." require>
                            </div>
                            <div class="bts-input">
                                <label for="Name">Prenom <span class="red">*</span></label>
                                <input type="text" autocomplete="off" placeholder="Votre Prenom..." require>
                            </div>
                        </div>
                        <div class="membre-bts">
                            <div class="bts-input">
                                <label for="Name">E-mail <span class="red">*</span></label>
                                <input type="email" autocomplete="off" placeholder="Votre E-mail..." require>
                            </div>
                            <div class="bts-input">
                                <label for="Name">Mot de passe <span class="red">*</span></label>
                                <input type="password" autocomplete="off" placeholder="Votre Mot de passe..." require>
                            </div>
                        </div>
                        <button class="btn">enregistrer</button>
                    </div>
                    </form>
                </div>
            </div>
        </section>

        <section class="presentation" id="presentation">
                <div class="content">
                    <div class="text-present">
                        <p>Tout projet entrepreneurial doit avoir un caractère social. 
                        Personne ne viendra développer l'Afrique si ses filles et fils ne se mettent pas ensemble pour créer des projets de développement.
                        Aujourd'hui, les africains doivent comprendre que l'Afrique a dépassé le stade où les "petits entrepreneurs" pouvaient facilement réussir.
                        Le continent est devenu la destination la plus prisée des gros investisseurs.
                        S'il faut attendre que chacun ait un portefeuille garni avant de démarrer une activité,
                        nous partons tout droit à la perte car le temps de rassembler les fonds, 
                        les potentiels investisseurs auront déjà envahi le marché.
                        La solution serait donc de mettre ensemble avec un frère et ou ami de même ethnie, 
                        religion, continent afin de créer des projets communautaires pour exceller dans certains domaines d'activités comme l'importation de poisson,
                        l'élevage, l'agriculture. Nous avons dépassé le stade où l'agriculteur lambda produit seulement 10 à 20 sacs de maïs pour la commercialisation,
                        quelques turbercules d'igname à présenter sur le marché. Nous sommes arrivés à un niveau où il faut industrialiser nos produits. Et pour ce fait, 
                        on a besoin de gros financement. Et si 100 personnes décident de se mettre ensemble avec un apport financier personnel afin d'investir dans un domaine quelconque, 
                        nous pensons qu'en 3 ou 4 mois les résultats seront visibles. Si nous avons donc compris l'intérêt d'entreprendre, pourquoi ne pas y associer l'union ?
                        100 Jeunes Entrepreneurs de Côte d'Ivoire se donne la mission de valoriser l'entrepreneuriat associatif.</p>
                        
                    </div>
                    <div class="photo-present">
                        <div class="image-present">
                            <img src="img/img01.png" alt="img/img01.png">
                            <span class="fondateur">M. NANAN MAIZAN</span>
                            <h6 class="fondat">Fondateur de 100JECI-SARL</h6>
                        </div>
                    </div>
                </div>
        </section>
        <section class="application">
            <div class="content-box">
                <div class="box">
                    <div class="titre">
                        <h3>Projets Realisés</h3>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                    </div>
                    <div class="button">
                        <a href="projets/liste-projet.php" target="_blank" class="btn">Afficher Projet</a>
                    </div>
                </div>
                <div class="box">
                    <div class="titre">
                        <h3>Projets En Cours</h3>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                    </div>
                    <div class="button">
                    <a href="projets/liste-projet.php" target="_blank" class="btn">Afficher Projet</a>
                    </div>
                </div>
                <div class="box">
                    <div class="titre">
                        <h3>Adherer un nouveau projet</h3>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                    </div>
                    <div class="button">
                        <a href="#" class="btn" id="btn-principal">Adherer Projets</a>
                    </div>
                </div>
            </div>
        </section>


        <section class="archivre">
            <h1 class="heading"> Publications de <span>100JECI</span></h1>

            <div class="content-box">
                <div class="box">
                    <div class="imgs-pub">
                        <img src="img/img02.png" alt="">
                    </div>
                    <p>Sous le Thème:</p>
                    <div class="admin">
                        <span class="theme">comment creer et developper plusieurs sources de revenus</span>
                        <h3 class="entrer">Entrer:</h3>
                    </div>
                    <div class="button">
                        <a href="#" class="btn">voir plus</a>
                    </div>
                </div>

                <div class="box">
                    <div class="imgs-pub">
                        <img src="img/img03.png" alt="">
                    </div>
                     <p>Sous le Thème:</p>
                     <div class="admin">
                        <span class="theme">comment creer et developper plusieurs sources de revenus</span>
                        <h3 class="entrer">Entrer:</h3>
                    </div>
                    <div class="button">
                        <a href="#" class="btn">voir plus</a>
                    </div>
                </div>

                <div class="box">
                    <div class="imgs-pub">
                        <img src="img/img01.png" alt="">
                    </div>
                    <p>theme:projet</p>
                    <div class="button">
                        <a href="#" class="btn">voir plus</a>
                    </div>
                </div>

                <div class="box">
                    <div class="imgs-pub">
                        <img src="img/img01.png" alt="">
                    </div>
                    <p>theme:projet</p>
                    <div class="button">
                        <a href="#" class="btn">voir plus</a>
                    </div>
                </div>
               
            </div>
        </section>

        <section class="partenaire">
            <h3 class="heading">les Partenaires de <span>100JECI-SARL</span> DISENT</h3>
            <div class="partenaire-content">
                <div class="box-partenaire">
                    <div class="nom-partenaire">
                        <h3>Awa</h3>
                    </div>
                    <div class="dits">
                        <p>
                            Bonsoir à tous. Personnellement, je n'ai pas eu besoin de témoignages pour investir.
                             Entreprendre c'est prendre des risques. Je me suis rendue à beoumi rencontrer M. Maizan.
                              J'ai pris connaissance des termes du contrat. J'étais en compagnie d'un magistrat 
                              (lui-même M. Maizan n'a pas su nos fonctions).
                             J'en suis à mon 2e contrat avec eux. Tout se passe bien grâce à Dieu.
                        </p>
                    </div>
                </div>

                <div class="box-partenaire">
                    <div class="nom-partenaire">
                        <h3>G.Kone</h3>
                    </div>
                    <div class="dits">
                        <p>
                            Personnellement,  je n'ai pas eu besoin de ces témoignages. 
                            Quand j'ai découvert 100JECI-SARL sur Facebook,  j'ai pris la peine de suivre les activités
                            sur Facebook pendant 2 mois. C'est après que je suis allé à Béoumi   pour rencontrer Maïzan 
                            et voire au moins si la chambre froide de Beoumi existait vraiment.  Je l'ai rencontré.
                            Nous avons échangé et il m'a fait visiter le site de CAPRILAND. Après je suis rentré à BOUAKÉ 
                            et j'ai investi. Je n'ai pas encore commencé à percevoir mes RSI mais j'ai confiance.
                            J'attends d'ailleurs avec impatience mon 1er RSI,  en début de décembre.  Qui ne risque rien
                            n'a rien n'est-ce pas ? 
                            Nous investissons, c'est à l'équipe dirigeante de mettre du sérieux, comme elle le fait déjà,
                            pour rassurer ceux qui sont déjà là et attirer d'autres personnes.  
                            Voilà !
                        </p>
                    </div>
                </div>
            </div>
        </section>

        
        <footer class="finish">
            <div class="lien-page">
                <a href="#" class="logo">100JECI</a>
                <div class="reseau">
                    <div class="share">
                        <a href="#" class="btn fab fa-facebook-f"></a>
                        <a href="#" class="btn fab fa-youtube"></a>
                        <a href="#" class="btn fab fa-whatsapp"></a>
                    </div>
                </div>
            </div>
            <div class="redirection">
                <h4 class="logo">Page de redirection</h4>
                <div class="this-page">
                    <a href="#" id="Accueil" class="">Accueil</a>
                    <a href="#" id="Actualités" class="">Actualités</a>
                </div>
                <h4 class="logo">contact</h4>
                <div class="contactangenda">
                    <a href="#" class="contact"> +225 01 03 50 77 53</a>
                    <a href="#">+225 07 47 13 10 04</a>
                    <h4 class="logo">agenda</h4>
                </div>
            </div>
            <div class="redirection">
                <h4 class="logo">Adresse E-mail</h4>
                <div class="this-page">
                    <a href="contact@100jeci.com " id="Accueil" class="">contact@100jeci.com </a>
                    
                </div>
                <h4 class="logo">Siège Social</h4>
                <div class="contactangenda">
                    <a href="#" class="contact">Béoumi.</a>
                    
                    <h4 class="logo">Représentants:</h4>
                    <a href="#">Abidjan, Korhogo, Odiénné et Bouaké.</a>
                </div>
            </div>
            <div class="forms-commentaire">
                <h3>commentaire</h3>
                <input type="textarea" placeholder="votre commentaire...">
                <input type="submit" class="btns" value="envoyer">
            </div>
        </footer>
<script src="JS/script.js"></script>
</body>
</html>
