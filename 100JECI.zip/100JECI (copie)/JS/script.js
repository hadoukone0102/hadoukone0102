const menuClic =document.querySelector('#menuBar');
const afficher = document.querySelector('.nav-bar');
menuClic.addEventListener('click', function(){
    afficher.classList.toggle('active');
    menuClic.classList.toggle('fa-times')
})

// formulaire de connection

const Ouvre = document.querySelector('#Ouvre');
const close =document.querySelector('#close');
const popup =document.querySelector('.popup');

function OpenBtn(){
    popup.classList.add('active');
}
function CloseBtn(){
    popup.classList.remove('active');
}

Ouvre.addEventListener('click', OpenBtn);
close.addEventListener('click', CloseBtn);


const popupSecond =document.querySelector('.popup-2');
let utilisateur =document.getElementById('utilisateur');
const close2 =document.querySelector('#close2');

function OpenBtn2(){
    popupSecond.classList.add('active');
}

function CloseBtn2(){
    popupSecond.classList.remove('active');
}

utilisateur.addEventListener('click', OpenBtn2);
close2.addEventListener('click', CloseBtn2);

// changer pour se connecter
const changerPourCnct = document.querySelector('#changement-1')
changerPourCnct.addEventListener('click', function(){
    popupSecond.classList.remove('active');
    popup.classList.add('active');
})
// changer pour s'inscrire brainda
const changerPourInscpt = document.querySelector('#changement-2')
changerPourInscpt.addEventListener('click', function(){
    popup.classList.remove('active');
    popupSecond.classList.add('active');
})
// pour la partie adherent 

const popupAdherent = document.querySelector('.popup-adherent');
const btnPrincipale= document.querySelector('#btn-principal');
const close3 =document.querySelector('#close3');

function Action(){
    popupAdherent.classList.add('active');
}
function CloseBtn3(){
    popupAdherent.classList.remove('active');
}
btnPrincipale.addEventListener('click', Action);
close3.addEventListener('click', CloseBtn3);


