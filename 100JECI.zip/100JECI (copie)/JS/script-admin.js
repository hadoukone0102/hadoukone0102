// pour le formulaire du add projets 

const addAfficher = document.querySelector('.add-projets');
const projetsAdd =document.querySelector('#projetsAdd');
const btnRed =document.querySelector('.btn-red');

function FermerAddProjet(){
    addAfficher.classList.toggle('active');
    addAfficherPartenaire.classList.remove('active');
    AddPublication.classList.remove('active');
    AddAdherent.classList.remove('active');
}
function RedOpperation(){
    addAfficher.classList.remove('active')
}
projetsAdd.addEventListener('click', FermerAddProjet);
btnRed.addEventListener('click', RedOpperation);

// partenaire 
const addAfficherPartenaire = document.querySelector('.add-partenaire');
const partenaireAdd = document.querySelector('#partenaireAdd')
const btnRedPartenaire =document.querySelector('.btn-red-2');


function FermerAddPartenaire(){
    addAfficherPartenaire.classList.toggle('active')
    AddPublication.classList.remove('active');
    addAfficher.classList.remove('active');
    AddAdherent.classList.remove('active');
}

function RedOpperationPartenaire(){
    addAfficherPartenaire.classList.remove('active')
}
partenaireAdd.addEventListener('click', FermerAddPartenaire);
btnRedPartenaire.addEventListener('click', RedOpperationPartenaire);



// publication 
const AddPublication = document.querySelector('.add-publication');
const publicationAdd =document.querySelector('#publicationAdd');
const BtnClosePub = document.querySelector('.btn-red-3');

function FermerAddPublication(){
    AddPublication.classList.toggle('active')
    addAfficherPartenaire.classList.remove('active')
    addAfficher.classList.remove('active');
    AddAdherent.classList.remove('active');
}

function RedOpperationPublication(){
    AddPublication.classList.remove('active')
}

publicationAdd.addEventListener('click', FermerAddPublication);
BtnClosePub.addEventListener('click', RedOpperationPublication);


// Adherents 


const AddAdherent = document.querySelector('.add-adherent');
const AddAdherentBtn =document.querySelector('#AdherentAdd');
const BtnCloseAdherent = document.querySelector('.btn-red-4');

function FermerAddAdherent(){
    console.log('merci seigneur');
    AddAdherent.classList.toggle('active');
    AddPublication.classList.remove('active');
    addAfficherPartenaire.classList.remove('active');
    addAfficher.classList.remove('active');
}

function RedOpperationAdherent(){
    AddAdherent.classList.remove('active');
}

AddAdherentBtn.addEventListener('click', FermerAddAdherent);
BtnCloseAdherent.addEventListener('click', RedOpperationAdherent);