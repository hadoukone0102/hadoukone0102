<footer class="finish">
            <div class="lien-page">
                <a href="#" class="logo">100JECI</a>
                <div class="reseau">
                    <div class="share">
                        <a href="#" class="btn fab fa-facebook-f"></a>
                        <a href="#" class="btn fab fa-youtube"></a>
                        <a href="#" class="btn fab fa-whatsapp"></a>
                    </div>
                </div>
            </div>
            <div class="redirection">
                <h4 class="logo">Page de redirection</h4>
                <div class="this-page">
                    <a href="#" id="Accueil" class="">Accueil</a>
                    <a href="#" id="Actualités" class="">Actualités</a>
                </div>
                <h4 class="logo">contact</h4>
                <div class="contactangenda">
                    <a href="#" class="contact"> +225 01 03 50 77 53</a>
                    <a href="#">+225 07 47 13 10 04</a>
                    <h4 class="logo">agenda</h4>
                </div>
            </div>
            <div class="redirection">
                <h4 class="logo">Adresse E-mail</h4>
                <div class="this-page">
                    <a href="contact@100jeci.com " id="Accueil" class="">contact@100jeci.com </a>
                    
                </div>
                <h4 class="logo">Siège Social</h4>
                <div class="contactangenda">
                    <a href="#" class="contact">Béoumi.</a>
                    
                    <h4 class="logo">Représentants:</h4>
                    <a href="#">Abidjan, Korhogo, Odiénné et Bouaké.</a>
                </div>
            </div>
            <div class="forms-commentaire">
                <h3>commentaire</h3>
                <input type="textarea" placeholder="votre commentaire...">
                <input type="submit" class="btns" value="envoyer">
            </div>
        </footer>
<script src="JS/script.js"></script>
</body>
</html>
