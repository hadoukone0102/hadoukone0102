<?php  
require('../fluide/head.php');
?>

        <section class="archivre">
            <h1 class="heading"> Liste des projets de <span>100JECI</span></h1>

            <div class="content-box">
                <div class="box">
                    <div class="imgs-pub">
                        <img src="../img/img02.png" alt="">
                    </div>
                    <p>Sous le Thème:</p>
                    <div class="admin">
                        <span class="theme">comment creer et developper plusieurs sources de revenus</span>
                        <h3 class="entrer">Entrer: <span>2000</span></h3>
                        <p>Statut : <span>Terminé</span></p>
                    </div>
                    
                </div>

                <div class="box">
                    <div class="imgs-pub">
                        <img src="../img/img03.png" alt="">
                    </div>
                     <p>Sous le Thème:</p>
                     <div class="admin">
                        <span class="theme">comment creer et developper plusieurs sources de revenus</span>
                        <h3 class="entrer">Entrer: <span>GRATUIT</span></h3>
                        <p>Statut : <span>Terminé</span></p>
                    </div>
                </div>

               
               
            </div>
        </section>

<?php  
require('../fluide/footer.php');
?>