
let links = document.querySelectorAll('.meteo')
for(let i= 0; i<= links.length; i++){
    let link =links[i]
    link.addEventListener('click', function(e) {
            e.preventDefault()
            let httpRequest = new XMLHttpRequest()

            httpRequest.onreadystatechange = function(){
                if(httpRequest.readyState === 4){
                    document.getElementById('result').innerHTML = httpRequest.responseText 
                }
            }
            httpRequest.open('GET',this.getAttribute('href'),true)
            httpRequest.send()
    })
}



