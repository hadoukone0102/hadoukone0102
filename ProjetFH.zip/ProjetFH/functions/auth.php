<?php
function session_existe(){
    if(session_status() === PHP_SESSION_NONE){
        session_start();
    }
    if(empty($_SESSION['connecter'])){
        header('location:forms/form-clients.php');
        exit();
    }
}

?>