<?php 

setcookie('clients','Kone Hadou',time()+60*60*24);