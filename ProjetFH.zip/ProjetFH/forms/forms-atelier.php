<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Couturiers</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" 
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../CSS/style-forms-couturiers.css">
</head>
<body>
    
    <div class="container">

        <form action="#">
            <h3 class="header">form Atelier</h3>
            <div class="form-first">

                <div class="name">
                    <h3>personnel details</h3>
                    <div class="input-fils">
                        <label for="Name">name</label>
                        <input type="text" placeholder="your Name..." autocomplete="off">
                    </div>
                    <div class="input-fils">
                        <label for="Name">last-Name</label>
                        <input type="text" placeholder="your last-Name..." autocomplete="off">
                    </div>
                    <div class="input-fils">
                        <label for="Name">Phone Number</label>
                        <input type="number" placeholder="your number..." autocomplete="off">
                    </div>
                </div>


                <div class="name">
                    <h3>identify details</h3>
                    <div class="input-fils">
                        <label for="Name">name</label>
                        <input type="text" placeholder="your Name..." autocomplete="off">
                    </div>
                    <div class="input-fils">
                        <label for="Name">name</label>
                        <input type="text" placeholder="your Name..." autocomplete="off">
                    </div>
                    <div class="input-fils">
                        <label for="Name">name</label>
                        <input type="text" placeholder="your Name..." autocomplete="off">
                    </div>
                </div>

                <div class="name">
                    <h3>cantrise details</h3>
                    <div class="input-fils">
                        <label for="Name">name</label>
                        <input type="text" placeholder="your Name..." autocomplete="off">
                    </div>
                    <div class="input-fils">
                        <label for="Name">name</label>
                        <input type="text" placeholder="your Name..." autocomplete="off">
                    </div>
                    <div class="input-fils">
                        <label for="Name">name</label>
                        <input type="text" placeholder="your Name..." autocomplete="off">
                    </div>
                </div>

                <div class="name">
                    <div class="input-fils">
                        <label for="submit"></label>
                       <input type="submit" value="continuer" name="continuer" class="btn buttons" id="btn">
                    </div>
                </div>

            </div>

            
        </form>
    </div>

<script src="../JS/js-forms.js"></script>
</body>
</html>