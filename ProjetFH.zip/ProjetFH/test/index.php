<?php 
/*
try{
  $tadaBase = new PDO('mysql:host=localhost;dbname=projets','root','');
  echo"bingo";
}catch (PDOException $exc) {
  echo $exc->getMessage();
}

if(isset($_POST['send'])){
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    $sql ="INSERT INTO `maisons`(`latitude`,`longitude`) VALUES(:latitude,:longitude)";
    $req =$tadaBase->prepare($sql);
    $reponse = $req->execute(array(":latitude"=>$latitude,":longitude"=>$longitude));
    if($reponse){
        echo"bien joué";
    }else{
        echo"nn Hadou mauvais travail";
    }
}
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" action="Code.php">
  <input type="text" name="adresse" placeholder="Adresse">
  <input type="text" name="ville" placeholder="Ville">
  <input type="text" name="pays" placeholder="Pays">
  <input type="text" name="latitude" id="latitude" placeholder="Latitude">
  <input type="text" name="longitude" id="longitude" placeholder="Longitude">
  <div id="carte"></div>
  <button type="submit" name="send">Enregistrer</button>
  <?php

?>
</form>

    <script src="code.js"></script>
    <script src="script.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
  </body>
</html>