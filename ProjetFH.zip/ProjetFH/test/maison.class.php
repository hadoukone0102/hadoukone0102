<?php

class Maison {

  // pour la connexion au bd
  private $host = 'localhost';
  private $username = 'root';
  private $password ='';
  private $database ='projets';  
  private $db; 


  public function __construct($host =null,$username = null,$password = null, $database = null){

    if($host != null){
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->database = $database;
    }
    try{
        $this->db = new PDO("mysql:host=$this->host;dbname=$this->database",$this->username,$this->password,);
        echo "bingo";
    }catch(PDOException $e){
        die('impossible de connecter à la base de donnée'. $e->getMessage());
    }
}

public function query($sql){
  $requete = $this->db->prepare($sql);
 $reponse= $requete->execute();
 if($reponse){
  return $requete->fetchAll();
 }else{
  echo"impossible";
 }
  
}

public function inserer(string $latitude,string $longitude) {
  $requete = $this->db->prepare('INSERT INTO maisons (latitude, longitude) VALUES (?, ?)');
  $requete->execute([$latitude, $longitude]);
}
 
  public function enregistrer() {
    // Code pour enregistrer les informations de la maison dans la base de données
    //echo"bonjour";
  }

}

$home = new Maison('localhost','root','','projets');
$home->query("INSERT INTO maisons (latitude, longitude) VALUES (?, ?)");
