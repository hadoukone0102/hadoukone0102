
<?php

 class Code{
    private $host = 'localhost';
    private $username = 'root';
    private $password ='';
    private $database ='projets';  
    public $latitude ;
    public $longitude;
    private $db; 
  
  
    public function __construct($host =null,$username = null,$password = null, $database = null,$latitude=null,$longitude=null){
        
      if($host != null){
          $this->host = $host;
          $this->username = $username;
          $this->password = $password;
          $this->database = $database;
          $this->latitude=$latitude;
          $this->longitude= $longitude;
      }
      try{
          $this->db = new PDO("mysql:host=$this->host;dbname=$this->database",$this->username,$this->password,);
          echo "bingo";
      }catch(PDOException $e){
          die('impossible de connecter à la base de donnée'. $e->getMessage());
      }
  }

  public function inclusion(){
    
    $this->latitude = $_POST['latitude'];
    $this->longitude = $_POST['longitude'];
    var_dump($this->latitude, $this->longitude);
    $sql = "INSERT INTO `maisons`(`latitude`,`longitude`) VALUES(:latitude,:longitude)";
    $req = $this->db->prepare($sql);
    $reponse =$req->execute(array(":latitude"=>$this->latitude,":longitude"=>$this->longitude));
    if($reponse){
        echo"bien fait HADOU";
    }else{
        echo"echec KONE";
    }
    
  }

  public function JSON(){
    return json_encode(array(
        'latitude'=>$this->latitude,
        'longitude'=>$this->longitude
    ));
  }

  public function getList($sql){
    //$sql= "SELECT * from `maisons`";
    $requete = $this->db->prepare($sql);
    $requete->execute();
    return $requete->fetchAll();
  }

}




$code =new Code();
$code->inclusion();
$json =$code->JSON();
var_dump($json);
$listMaison =$code->getList("SELECT * from `maisons`");
var_dump($listMaison);
$maisonJSON = array();
foreach($listMaison as $maison){
    array_push($maisonJSON, $maison->JSON());
}
file_put_contents('maisons.json', json_encode($maisonsJSON));

?>
