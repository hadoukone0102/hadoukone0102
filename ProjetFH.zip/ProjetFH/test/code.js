class Carte {
  constructor(element) {
    this.element = element;
    this.markers = [];
    this.map = new google.maps.Map(element, {
      center: {lat: 0, lng: 0},
      zoom: 1
    });
    this.map.addListener('click', this._handleClick.bind(this));
  }

  _handleClick(event) {
    const marker = new google.maps.Marker({
      position: event.latLng,
      map: this.map
    });
    this.markers.push(marker);
    document.getElementById('latitude').value = event.latLng.lat();
    document.getElementById('longitude').value = event.latLng.lng();
  }


  afficherMaisons() {
    const request = new XMLHttpRequest();
    request.onreadystatechange = () => {
      if (request.readyState === 4 && request.status === 200) {
        const maisons = JSON.parse(request.responseText);
        maisons.forEach(maison => {
          const marker = new google.maps.Marker({
            position: {lat: parseFloat(maison.latitude), lng: parseFloat(maison.longitude)},
            map: this.map
          });
          this.markers.push(marker);
        });
      }
    };
    request.open('GET', 'maisons.json', true);
    request.send();
  }
}

const carte = new Carte(document.getElementById('carte'));
carte.afficherMaisons();
