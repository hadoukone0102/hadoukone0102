(function(){
    // pour le menu bars

    const menubar =document.getElementById('menuBar')
    const navbar =document.querySelector('.nabar')

    const dots = document.querySelector('.dots')
    const troispoints =document.getElementById('troispoints')

    troispoints.addEventListener('click', ()=>{
        dots.classList.toggle('active')
        troispoints.classList.toggle('fa-times')
        navbar.classList.remove('active')
        troispoints.classList.toggle('back')
        menubar.classList.remove('back')
        menubar.classList.remove('fa-times')
    })

    menubar.addEventListener('click',() =>{
        menubar.classList.toggle('back')
        menubar.classList.toggle('fa-times')
        navbar.classList.toggle('active')
        dots.classList.remove('active')
        troispoints.classList.remove('back')
        troispoints.classList.remove('fa-times')
        
    })


    // pour le scroll de window

    let header =document.querySelector('.header-2')
    window.onscroll= () =>{
        menubar.classList.remove('fa-times')
        navbar.classList.remove('active')
        dots.classList.remove('active')
        if(window.scrollY  <= 20){
            header.classList.remove('fixed')
        }else{
            header.classList.add('fixed')
        }
    }

let containerFixed = document.querySelector(".container")
let secondBoite =document.querySelector('.second-boite')

    // function
// par defaut je le met en display none
let contientVariable =secondBoite.classList.contains('displayNone')
if(!contientVariable){
    secondBoite.classList.add('displayNone')
}


    // function de redimenssionnement 

    function redimenssioner(){
        if(window.innerWidth <= 768){
  
              containerFixed.classList.add('displayNone')
              secondBoite.classList.remove('displayNone')
              secondBoite.classList.add('displayFlex')
          }
  
      }
    window.onresize = redimenssioner

})()
