<?php 

if(isset($_POST['submit-couture'])){
    if(!empty($_POST['email-coutures']) and !empty($_POST['mdp-couture'])){
        $email_clients = $_POST['email-coutures'];
        $mdp_clients = $_POST['mdp-couture'];
        $bravo="Bon(ne) couturier(e)";
    }else{
        $bravo="Mauvais(se) couturier(e)";
    }
}

?>