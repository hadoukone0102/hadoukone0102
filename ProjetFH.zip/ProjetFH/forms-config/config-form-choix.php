<?php

if(isset($_POST['submit-clients'])){
    if(!empty($_POST['email-client']) and !empty($_POST['mdp-clients'])){

        $email_clients = $_POST['email-client'];
        $mdp_clients = $_POST['mdp-clients'];
        header('location:../forms/form-clients.php');
    }else{
        $bravo="svp rempisez tous les champs";
    }
   
}

if(isset($_POST['submit-couture'])){
    if(!empty($_POST['email-coutures']) and !empty($_POST['mdp-couture'])){
        $email_couture = $_POST['email-coutures'];
        $mdp_couture = $_POST['mdp-couture'];
        header('location:../forms/forms-couturier.php');
    }else{
        $bravos="Vauvais(ne) couturier(e)";
    }
}

?>