<?php
require_once ('../db.class.php');
$DB = new DB();

if(isset($_POST['send'])){
    if(
        !empty($_POST['nom-clients']) && 
        !empty($_POST['prenom-clients']) &&  
        !empty($_POST['adresse-clients']) && 
        !empty($_POST['statut']) && 
        !empty($_POST['taille']) && 
        !empty($_POST['mesures']) && 
        !empty($_POST['villes']) && 
        !empty($_POST['quartier']) && 
        !empty($_POST['number']) &&
        !empty($_POST['sexe'])
        )
        {

            $NomClients = $_POST['nom-clients'];
            $PrenomClient = $_POST['prenom-clients'];
            $addressClients = $_POST['adresse-clients'];
            $statutsClients = $_POST['statut'];
            $tailleClients = $_POST['taille'];
            $mesuresClients =$_POST['mesures'];
            $villeClients =$_POST['villes'];
            $quartierClients =$_POST['quartier'];
            $phoneClients =$_POST['number'];
            $sexeClients = $_POST['sexe'];

 /*     $sql = "INSERT INTO `users`(`firstname`, `lastname`) VALUES (:firstname,:lastname)"; 
    $res = $pdo->prepare($sql);
    $exec = $res->execute(array(":firstname"=>$firstname,":lastname"=>$lastname));
    */
         $sql = ("INSERT INTO `clients` (
                `nom `,
                ` prenom `,
                `adresse `,
                `numero`,
                ` sexe `,
                `ville`,
                `statut`,
                `tailles`,
                `mesures`,
                `quatier`

                ) VALUES(:nom,:prenom,:adresse,:numero,:sexe,:ville,:statut,:tailles,:mesures,:quatier)");
        $reponse = $pdo->prepare($sql);
        $executionReponse =$reponse->execute(array(
            ":nom"=>$NomClients,
            ":prenom"=>$PrenomClient,
            ":adresse"=>$addressClients,
            ":numero"=>$phoneClients,
            ":sexe"=>$sexeClients,
            ":ville"=>$villeClients,
            ":statut"=>$statutsClients,
            ":tailles"=>$tailleClients,
            ":mesures"=>$mesuresClients,
            ":quatier"=>$quartierClients
        ));
        if($executionReponse){
            $error ="ajouter avec succès";
        }else{
            $error ="impossible HAdou";
        }


            $info_clients =array($NomClients ,
                $PrenomClient,
                $addressClients,
                $statutsClients,
                $tailleClients,
                $mesuresClients,
                $villeClients,
                $quartierClients,
                $phoneClients,
                $sexeClients
        );
            //require('../functions/auth.php');
            session_start();
            $_SESSION['connecter'] = $info_clients ;
            
           // header('location:../home.php');
           
           
         

    }
    else{
            $error ="impossible d'acceder à la page";
    }
}



/* =>  */





?>