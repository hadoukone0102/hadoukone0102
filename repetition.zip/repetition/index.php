<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Designe</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" 
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
       
    <header>
        <div class="header-1">
            <a href="#" class="logo"><i class="fas fa-shopping-basket"></i>Shopping</a>
            <form action="#" class="search-box-container">
                <input type="search" class="searchInput" id="searchInput" placeholder="Search..." autocomplete="off">
                <label for="search-input" class="fas fa-search"></label>
            </form>
        </div>
        <div class="header-2">
            <div id="menuBar" class="fas fa-bars"></div>
            <nav class="nab-bar">
                <a href="#" id="home">Home</a>
                <a href="#" id="category">Banner</a>
                <a href="#" id="product">Product</a>
                <a href="#" id="about">About</a>
                <a href="#" id="contact">Contact</a>
            </nav>
            <div class="icons">
                <a href="#" class="fas fa-shopping-cart"></a>
                <a href="#" class="fas fa-heart"></a>
                <a href="forms/form-clients.php" class="fas fa-user-circle"></a>
            </div>
        </div>
    </header>

    <section class="home" id="home">
        <div class="image">
            <img src="img/burger1.png" alt="burger1">
        </div>
        <div class="content">
            <span>Soyez les Bienvenue</span>
            <h3>Shopping pour tous</h3>
            <a href="#" class="btn">add panier</a>
        </div>
    </section>

    <section class="banner-container" id="banner">

        
        <div class="banner">
            <img src="img/cake.png" alt="cake">
            <div class="content">
                <p>spaecial offre</p>
                <h3>upto 45% off</h3>
                <a href="#" class="btn">check out</a>
            </div>
        </div>

        <div class="banner">
            <img src="img/cake1.png" alt="cake">
            <div class="content">
                <p>limited offre</p>
                <h3>upto 55% off</h3>
                <a href="#" class="btn">check out</a>
            </div>
        </div>

    </section>
    <section class="category" id="category">

        <h1 class="heading">chopping from <span>Category</span></h1>

        <div class="box-container">

           <div class="box">
                <h3>vegetable</h3>
                <p>upto 45% off</p>
                <img src="img/vegetable.png" alt="cake">
                <a href="#" class="btn">chop now</a>
           </div>

           <div class="box">
                <h3>juice</h3>
                <p>upto 45% off</p>
                <img src="img/juice.jpg" alt="cake">
                <a href="#" class="btn">chop now</a>
            </div>

            <div class="box">
                <h3>ananas</h3>
                <p>upto 45% off</p>
                <img src="img/ananas.jpg" alt="cake">
                <a href="#" class="btn">chop now</a>
            </div>

            <div class="box">
                <h3>fruits</h3>
                <p>upto 35% off</p>
                <img src="img/fruit.jpg" alt="cake">
                <a href="#" class="btn">chop now</a>
            </div>

       </div>
    </section>
    <section class="product" id="product">
        <h1 class="heading">shop by <span>Products</span></h1>
            <div class="product-container">
                <div class="box">
                    <p>-45%</p>
                    <div class="shar">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="#" class="fas fa-shopping-cart"></a>
                        <a href="#" class="fas fa-eye"></a>
                    </div>
                    <img src="img/cake.png" alt="">
                    <h3>organic ttttt</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">10.0$ <span>13.5$</span></div>
                    <div class="quatity">
                        <span>quantity :</span>
                        <input type="number" class="number" min="1" max="1000" value="1">
                        <span>  /kg</span>
                    </div>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="box">
                    <p>-40%</p>
                    <div class="shar">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="#" class="fas fa-shopping-cart"></a>
                        <a href="#" class="fas fa-eye"></a>
                    </div>
                    <img src="img/cake.png" alt="">
                    <h3>organic ttttt</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">10.0$ <span>13.5$</span></div>
                    <div class="quatity">
                        <span>quantity :</span>
                        <input type="number" class="number" min="1" max="1000" value="1">
                        <span>  /kg</span>
                    </div>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="box">
                    <p>-35%</p>
                    <div class="shar">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="#" class="fas fa-shopping-cart"></a>
                        <a href="#" class="fas fa-eye"></a>
                    </div>
                    <img src="img/cake.png" alt="">
                    <h3>organic ttttt</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">10.0$ <span>13.5$</span></div>
                    <div class="quatity">
                        <span>quantity :</span>
                        <input type="number" class="number" min="1" max="1000" value="1">
                        <span>  /kg</span>
                    </div>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="box">
                    <p>-45%</p>
                    <div class="shar">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="#" class="fas fa-shopping-cart"></a>
                        <a href="#" class="fas fa-eye"></a>
                    </div>
                    <img src="img/cake.png" alt="">
                    <h3>organic ttttt</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">10.0$ <span>13.5$</span></div>
                    <div class="quatity">
                        <span>quantity :</span>
                        <input type="number" class="number" min="1" max="1000" value="1">
                        <span>  /kg</span>
                    </div>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="box">
                    <p>-55%</p>
                    <div class="shar">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="#" class="fas fa-shopping-cart"></a>
                        <a href="#" class="fas fa-eye"></a>
                    </div>
                    <img src="img/cake.png" alt="">
                    <h3>organic ttttt</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">10.0$ <span>13.5$</span></div>
                    <div class="quatity">
                        <span>quantity :</span>
                        <input type="number" class="number" min="1" max="1000" value="1">
                        <span>  /kg</span>
                    </div>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="box">
                    <p>-25%</p>
                    <div class="shar">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="#" class="fas fa-shopping-cart"></a>
                        <a href="#" class="fas fa-eye"></a>
                    </div>
                    <img src="img/cake.png" alt="">
                    <h3>organic ttttt</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">10.0$ <span>13.5$</span></div>
                    <div class="quatity">
                        <span>quantity :</span>
                        <input type="number" class="number" min="1" max="1000" value="1">
                        <span>  /kg</span>
                    </div>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="box">
                    <p>-15%</p>
                    <div class="shar">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="#" class="fas fa-shopping-cart"></a>
                        <a href="#" class="fas fa-eye"></a>
                    </div>
                    <img src="img/cake.png" alt="">
                    <h3>organic ttttt</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">10.0$ <span>13.5$</span></div>
                    <div class="quatity">
                        <span>quantity :</span>
                        <input type="number" class="number" min="1" max="1000" value="1">
                        <span>  /kg</span>
                    </div>
                    <a href="#" class="btn">shop now</a>
                </div>
                <div class="box">
                    <p>-15%</p>
                    <div class="shar">
                        <a href="#" class="fas fa-heart"></a>
                        <a href="#" class="fas fa-shopping-cart"></a>
                        <a href="#" class="fas fa-eye"></a>
                    </div>
                    <img src="img/cake.png" alt="">
                    <h3>organic ttttt</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">10.0$ <span>13.5$</span></div>
                    <div class="quatity">
                        <span>quantity :</span>
                        <input type="number" class="number" min="1" max="1000" value="1">
                        <span>  /kg</span>
                    </div>
                    <a href="#" class="btn">shop now</a>
                </div>
            </div>
    </section>

<!--autre section start -->

    <section class="offres-container" id="offres">
        <div class="offres">
            <div class="content">
                <h1> deal of the day</h1>
                <div class="msg">
                    <h3>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident, sunt.</h3>
                    <p>offre limited</p>
                </div>
                <div class="times">
                    <div id="regle">
                        <p id="day">00</p>
                        <span>day</span>
                    </div>
                    <div id="regle">
                        <p id="heurs">00</p>
                        <span>heurs</span>
                    </div>
                    <div id="regle">
                        <p id="minute">00</p>
                        <span>minutes</span>
                    </div>
                    <div id="regle">
                        <p id="second">00</p>   
                        <span>seconds</span>
                    </div>
                </div>
                <a href="#" class="btn">check the deal</a>
            </div>
        </div>
    </section>
<!-- section end-->
<!--form part star -->
<section class="Contact" id="contact">
    <h1 class="heading"><span>contact</span> US</h1>
    <form action="#">

        <div class="inputBox">
            <input type="text" placeholder="your name">
            <input type="email" placeholder="your email address">
        </div>

        <div class="inputBox">
            <input type="number" placeholder="your number">
            <input type="email" placeholder="your subjet">
        </div>
        <textarea name="" id="" cols="30" rows="10" placeholder="message"></textarea>
        <input type="submit" class="btn" value="send message">
    </form>
</section>
<!-- form part end-->
<!-- newlester section start -->
<section class="newlester" id="newlester">
    <h1 class="heading"><span>subscribe</span> now</h1>
    <form action="">
        <div class="new-content">
        <input type="email" placeholder="your email please...">
        </div>
        <a href="#" class="btn">subscribe</a>
    </form>
</section>
<!--section end -->
<!-- footer section start -->

    <section class="footer" id="footer">
        <div class="box-container">
            <div class="box">
                <a href="#" class="logo"><i class="fas fa-shopping-basket"></i>hkservice</a>
                <p>atque velit placeat sequi unde veniam ut consequatur aliquid.</p>
                <div class="share">
                    <a href="#" class="btn fab fa-facebook-f"></a>
                    <a href="#" class="btn fab fa-twitter"></a>
                    <a href="#" class="btn fab fa-instagram"></a>
                    <a href="#" class="btn fab fa-linkedin"></a>
                </div>

            </div>

            <div class="box">
               <h3>quick links</h3>
                <div class="head">
                    <a href="#" id="home">Home</a>
                    <a href="#" id="product">Product</a>
                    <a href="#" id="banner">banner</a>
                    <a href="#" id="category">category</a>
                    <a href="#" id="contact">contact</a>
                </div>

            </div>


            <div class="box">
               <h3>links</h3>
                <div class="countries">
                    <a href="#" >Ivory</a>
                    <a href="#" >Mali</a>
                    <a href="#" >Burkina</a>
                    <a href="#" >Guinne</a>
                    <a href="#">sénegale</a>
                </div>

            </div>


            <div class="box">
               <h3>my requete</h3>
                <form action="#">
                    <input type="email" placeholder="your emai..." autocomplete="off">
                    <input type="password" placeholder="your emai..." autocomplete="off">
                    <input type="submit" value="send message" class="btn">
                </form>

            </div>


        </div>
        <h1 class="credit" >create by <span>mr. Hadou kone</span> | all rights Reserced!</h1>
    </section>

<!-- footer end-->
<!-- -->
    <script src="JS/script.js"></script>
</body>
</html>