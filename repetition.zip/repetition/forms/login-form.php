<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="../CSS/style-login.css">
</head>
<body>
    <div class="container">
        <div class="conetent">
            <div class="box-content">
                <div class="first-party">
                <h3 ><span id="titre">Fashion House</span></h3>
                    <p class="text">
                        Pour la securité et la confidentialité de vos données,
                    </p>
                    <p class="text">
                        <span id="titre">Fahsion House </span> prend des dispositions néccessaires.
                    </p>
                    <p class="text">
                        Nous vous prions de bien vouloir vous identifier si vous avez déja 
                    </p>
                    <p class="text">
                        un compte ou cliquer sur <a href="choix.php">inscription</a> pour en créer un
                    </p>
                </div>
                <form action="#" class="login-forms">
                    <h3>login form</h3>
                    <div class="second-party">
                        <div class="login-part">
                            <label for="inputEmail">your email please !</label>
                        <input type="email" placeholder="email ..." autocomplete="Off">
                        </div>
                        <div class="login-part">
                            <label for="InputPassword">Enter your password</label>
                            <input type="password" autocomplete="off" placeholder="password ...">
                        </div>
                        <div class="login-part">
                            <input type="submit" value="Envoyer" class="btn">
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</body>
</html>