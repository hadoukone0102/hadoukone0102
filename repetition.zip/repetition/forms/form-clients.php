<?php
require_once('../config/database.php');

?>
<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Clients</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" 
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../CSS/style-forms-clients.css">
</head>
<body>
    <div class="container">

        <div class="content">
            <h1> <i class="fas fa-user-circle"></i> form Clients </h1>
            <form action="#" class="form-box" method="post">
                <div class="name">

                    <h3>informations personnel</h3>
                    <div class="input-block">
                        <label for="Name">name <span>*</span></label>
                        <input type="text" placeholder="your Name..." name="nom" autocomplete="off" required>
                    </div>

                    <div class="input-block">
                        <label for="Name">last-Name <span>*</span></label>
                        <input type="text" placeholder="your last-Name..." name="prenom" autocomplete="off" required>
                    </div>
                    
                    <div class="input-block">
                        <label for="Name">email <span>*</span></label>
                        <input type="email" placeholder="your email..." name="email" autocomplete="off">
                    </div>
                    
                </div>
                
                <div class="name">
                    
                    <h3></h3>
                        <div class="input-block">
                            <label for="Name">phone number <span>*</span></label>
                            <input type="number" placeholder="your number..." name="number" autocomplete="off" required>
                        </div>

                        <div class="input-block">
                            <label for="Name">city clients <span>*</span></label>
                            <input type="text" placeholder="your city..." name="city" autocomplete="off" required>
                        </div>
                   
                </div>
                <div class="name">
                    <div class="input-block">
                        <label for=""></label>
                        <input type="submit" class="btn" value="continuer" name="send">
                    </div>
                    <div class="input-block">
                        <p style="color:red;"><?php  if(isset($error)){echo"$error";} ?> </p>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>