<?php

class Database
{

    private $host ='localhost';
    private $username='root';
    private $dbname='foods';
    private $mdp ='';
    public $data;

    public function __construct($hsot =NULL,$username =NULL,$dbname =NULL,$mdp =NULL){
        if($host =! NULL){
            $this->host=$host;
            $this->username=$username;
            $this->dbname=$dbname;
            $this->mdp=$mdp;
        }
        try{
            $this->data =new PDO("mysql:localhost=$this->host;dbname=$this->dbname",$this->username,$this->mdp);
            echo "avec succès";
        }catch(PDOException $e){
            die('impossible de connceté à la base de donnée'. $e->getMessage());
        }
    }
}


class Operation extends Database
{

    public $name ;
	public $prenom ;
	public $email ;
	public $contact;
	public $ville ;
	public $button ;

    public function __construct($name,$prenom,$email,$contact,$ville,){
        parent::__construct($data);
			$this->name =$name;
			$this->prenom =$prenom;
			$this->email =$email;
			$this->contact =$contact;
			$this->ville=$ville;
			$this->button=$button;
	}

    public function insertion($noms,$prenoms ,$emails,$contacts,$villes){
		$noms=$_POST[$this->name];
		$prenoms = $_POST[$this->prenom];
		$emails = $_POST[$this->email];
		$contacts = $_POST[$this->contact];
		$villes = $_POST[$this->ville];
		//$buttons = $_POST[$this->button];
		var_dump($noms,$prenoms,$emails,$contacts,$villes);
        
				$sql = "INSERT INTO `clients`(`nom`,`prenom`,`email`,`contact`,`ville`) VALUES(:nom,:prenom,:email,:contact,:ville)";
				$resq =$this->data->prepare($sql);
				$reponse=$resq->execute(array(":nom"=>$noms,":prenom"=>$prenoms,":email"=>$emails,":contact"=>$contacts,":ville"=>$villes,));
				if($reponse){
					echo"inserer dxfcgvhbjnjlhb rcfgvpoikljnhbxfcghbipoljkhbxfc g";
				}else{
					echo"mauvais travail hadou";
				}
            
        }
}
$bd = new Database();
$requete = new Operation('nom','prenom','email','number','city');
$requete->insertion('nom','prenom','email','number','city');
?>