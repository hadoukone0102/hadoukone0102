<?php

require_once('database.php');
$DB =new Database();

class Operation{

	public $name ;
	public $prenom ;
	public $email ;
	public $contact;
	public $ville ;
	public $button ;

	public function __construct($name=null,$prenom=null,$email=null,$contact=null,$ville=null,$button=null){
		if($button =! null){
			$this->name =$name;
			$this->prenom =$prenom;
			$this->email =$email;
			$this->contact =$contact;
			$this->ville=$ville;
			$this->button=$button;
		}
	}

	public function insertion($noms,$prenoms ,$emails,$contacts,$villes,$buttons){
		$noms=$_POST[$this->name];
		$prenoms = $_POST[$this->prenom];
		$emails = $_POST[$this->email];
		$contacts = $_POST[$this->contact];
		$villes = $_POST[$this->ville];
		$buttons = $_POST[$this->button];
		var_dump($noms,$prenoms,$emails,$contacts,$villes,$buttons );
			if(isset($buttons)){
				$sql = "INSERT INTO `clients`(`nom`,`prenom`,`email`,`contact`,`ville`) VALUES(:nom,:prenom,:email,:contact,:ville)";
				$resq =$this->data->prepare($sql);
				$reponse=$resq->execute(array(":nom"=>$noms,":prenom"=>$prenoms,":email"=>$emails,":contact"=>$contacts,":ville"=>$villes,));
				if($reponse){
					echo"inserer";
				}else{
					echo"mauvais travail hadou";
				}
			
			}else{
				echo"desolé";
			}
		
	}


}

$requete = new Operation('nom','prenom','email','number','city');
$requete->insertion('nom','prenom','email','number','city');