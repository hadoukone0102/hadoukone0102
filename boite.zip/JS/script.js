(function(){
    const menuBar =document.getElementById('menuBar')
    const navBar =  document.querySelector('.navbar')
    menuBar.addEventListener('click',() =>{
        menuBar.classList.toggle('fa-times')
        navBar.classList.toggle('active')
    })
})()