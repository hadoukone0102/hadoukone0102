<?php
class Employe{

    // le constructeur

    var $nom;
    var $salaire;

     function __construct($n,$s){
        $this->nom=$n;
        $this->salaire=$s;
     }
     // la methode

     function response(){
        return "mon est $this->nom et mon salire est $this->salaire \n";
     }
   
}
class personne extends Employe{
    function heritage(){
        return 'ok';
    }
}

$result = new Employe('kone hadou',500000);
$second = new personne();
echo $result->response();
echo $second->heritage();
