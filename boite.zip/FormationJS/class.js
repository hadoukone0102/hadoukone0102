class Animal{
    constructor(NomAnimal){
        this.NomAnimal =NomAnimal
    }
    get Area(){
        return this.parle()
    }
    parle(){
        console.log(`${this.NomAnimal} fait du bruit`)
    }
}

class Chien extends Animal{
    constructor(NomAnimal,moiMeme){
        super(NomAnimal)
        this.moiMeme =moiMeme
    }
    parler(){
        console.log(`${this.NomAnimal} aboie je suis moi meme ${this.moiMeme}`)
    }
}
class chios extends Chien{
    constructor(NomAnimal,moiMeme){
        super(NomAnimal,moiMeme)
    }
    parleMoins(){
    return `${this.NomAnimal} je ne parle pas`
    }
}

class Lion extends chios{
    parler(){
        super.parler();
        console.log(`${this.nom} rugit`)
    }
}
const parent = new Animal('brolie')
const lion = new Lion('king')
console.log(lion.Area)
console.log(parent.Area)

