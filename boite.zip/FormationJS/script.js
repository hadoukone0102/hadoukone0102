let button =document.querySelector('#button')
let image =document.querySelector('#image')
let pokeNumber =document.querySelector('#number')
let pokeName =document.querySelector('#name')



// function

const changePokemon =async () =>{
    let randomNumber = Math.ceil(Math.random() * 150) + 1

    let requestString = `https://pokeapi.co/api/v2/pokemon/${randomNumber}`
    // pour faire une requete en js on utilise la function fetch
    let data = await fetch(requestString)
    // conversion en JSON

    let response = await data.json()

    image.src=response.sprites.front_default;
    pokeName.textContent = response.name
    pokeNumber.textContent= `#${response.id}`

    console.log(response)
}
changePokemon()
button.addEventListener('click',changePokemon)
